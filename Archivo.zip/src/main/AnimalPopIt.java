package main;

public class AnimalPopIt{

	/**
	 * Metodo que inicia el menu principal
	 * @param args
	 */
	public static void main(String[] args) {
		new MainMenu();
	}
}
class options {

	/* Clase que nos permite configurar la resolucion a la cual se ejecuta el juego

	 */
	protected static final int WIDTH = 1514,  HEIGHT = 1080;
	
	private options(){
		
		
	}
	
}